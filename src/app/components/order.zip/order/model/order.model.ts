export class Order {
    orderid: number;
    products: string;
    timestamp: Date;
    total: DoubleRange;
    zipcode: number;
    customerId: number;
    employeeId: number;
}
